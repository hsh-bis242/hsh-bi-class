create table hub_termintreue
(
    termintreue_sk        bytea,
    audit_trail_id        integer,
    inscription_timestamp varchar(1000),
    termintreue_id        char(100),
    data_delivery_key     bigint
);

alter table hub_termintreue
    owner to postgres;

INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x00000000000000000000000000000000', -1, '1900-01-01', 'Unknown                                                                                             ', 0);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x1A2C946F0FE25F86A20D2E98EBFD7E2A', -1, '2023-09-25 13:52:13.8657538', '5                                                                                                   ', 5);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x23B10E85FAA6A96103931520E8D68363', -1, '2023-09-25 13:52:13.8657538', '6                                                                                                   ', 6);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x2754D949FFAC55AC084BBD2C76D6A129', -1, '2023-09-26 05:49:03.3842190', '10                                                                                                  ', 10);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x3775A7ED78FD4A985F512D5C2D820603', -1, '2023-09-25 13:52:13.8657538', '3                                                                                                   ', 3);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x3ACFF0550A5BB57E3D4834F6B81A9777', -1, '2023-09-25 13:52:13.8657538', '9                                                                                                   ', 9);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x643557C21F16473BBE497ABFC8C6E7E3', -1, '2023-09-25 13:52:13.8657538', '8                                                                                                   ', 8);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\x9EBAFA93BE8C45C51F8AFF1B05B82A99', -1, '2023-09-25 13:52:13.8657538', '7                                                                                                   ', 7);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\xCD5F506F2905AFF53CEC094C91189FB9', -1, '2023-09-25 13:52:13.8657538', '2                                                                                                   ', 2);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\xD090549DDA0C9CEA33A2730316B2884F', -1, '2023-09-25 13:52:13.8657538', '1                                                                                                   ', 1);
INSERT INTO public.hub_termintreue (termintreue_sk, audit_trail_id, inscription_timestamp, termintreue_id, data_delivery_key) VALUES (E'\\xDB04178DEA049779B95D64AA8E0C93D2', -1, '2023-09-25 13:52:13.8657538', '4                                                                                                   ', 4);
