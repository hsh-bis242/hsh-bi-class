create table lnk_vereinspartner_kunde
(
    vereinspartner_kunde_sk bytea,
    audit_trail_id          integer,
    inscription_timestamp   varchar(1000),
    vereinspartner_sk       bytea,
    kunde_sk                bytea,
    row_nr                  bigint
);

alter table lnk_vereinspartner_kunde
    owner to postgres;

INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x630A20BEA6A5D703E405C99486078994', -1, '2023-09-26 05:49:03.4346299', E'\\xC7E07D31149CB8C2EEDB7C16877DACC7', E'\\x11B6B7F4567404452CC725A32A9BE6D0', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x397B0F3E040437881FADE7F4F454FD92', -1, '2023-09-25 13:52:13.9160155', E'\\xDAD7E35BC3D4E95F4B35274B4167FBAE', E'\\xDFDF065D0B8F61E7D9F4ABF2DBCACB61', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x140B639B6B991E41155E850D3B445F01', -1, '2023-09-25 13:52:13.9160155', E'\\x3CF5F8C695A04AB2CB015D1E349D74AD', E'\\xE3FE877F9749907557B1ABD24286691C', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x0077E411AB6BF9EC59404A501549D144', -1, '2023-09-25 13:52:13.9160155', E'\\x22B8B09DD7BC7744C383119F88C94567', E'\\x1A2C946F0FE25F86A20D2E98EBFD7E2A', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\xF28DDF9F9A155FB3FC4FE15B3D196679', -1, '2023-09-26 05:49:03.4346299', E'\\x87F98FECDB432A8CF4300A0778BBB350', E'\\x1A2C946F0FE25F86A20D2E98EBFD7E2A', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x95A1EE853613C59AAFC664C5AF8DB13F', -1, '2023-09-27 05:47:05.1416046', E'\\x048F8058B1B0D26BEAE96EDCDC7109CD', E'\\x941290B20C12D6E298AE5F35CE69E0D8', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x34D7022CCFC96B1BCE712CFB31D4006B', -1, '2023-09-25 13:52:13.9160155', E'\\x02DF303B4BF4E13F0652A80EB27E69CD', E'\\x941290B20C12D6E298AE5F35CE69E0D8', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\xEAB8296F48E43EA91651178D8EBBE30B', -1, '2023-09-25 13:52:13.9160155', E'\\x97FBAB3648559A0E89AC28BFD8C5BFA5', E'\\x2E9EAEC8C553455DFAF327E07442C794', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x296E9A6E2F55C3E37472C0DB33547AAD', -1, '2023-09-25 13:52:13.9160155', E'\\x17DE42B3EED787BD508553E2872B7472', E'\\xDAB96BA7D7E52A9A82ED79DCEC3B59A5', 1);
INSERT INTO public.lnk_vereinspartner_kunde (vereinspartner_kunde_sk, audit_trail_id, inscription_timestamp, vereinspartner_sk, kunde_sk, row_nr) VALUES (E'\\x96AF4777F81BB7F234C540FE2DB9A216', -1, '2023-09-26 05:49:03.4346299', E'\\x5DA41215EEAA0E2A1B3C57F8E088C491', E'\\xDAB96BA7D7E52A9A82ED79DCEC3B59A5', 1);
