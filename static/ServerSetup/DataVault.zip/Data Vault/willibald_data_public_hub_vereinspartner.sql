create table hub_vereinspartner
(
    vereinspartner_sk     bytea,
    audit_trail_id        integer,
    inscription_timestamp varchar(1000),
    vereinspartner_id     char(100),
    data_delivery_key     bigint
);

alter table hub_vereinspartner
    owner to postgres;

INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x00000000000000000000000000000000', -1, '1900-01-01', 'Unknown                                                                                             ', 0);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x02DF303B4BF4E13F0652A80EB27E69CD', -1, '2023-09-25 13:52:13.3145658', 'Ruhrmorig                                                                                           ', 4);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x048F8058B1B0D26BEAE96EDCDC7109CD', -1, '2023-09-27 05:47:04.0908078', 'Morgenstern                                                                                         ', 10);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x17DE42B3EED787BD508553E2872B7472', -1, '2023-09-25 13:52:13.3145658', 'WochenendGL?ck                                                                                      ', 6);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x22B8B09DD7BC7744C383119F88C94567', -1, '2023-09-25 13:52:13.3145658', 'Gl?ckAuf                                                                                            ', 3);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x3CF5F8C695A04AB2CB015D1E349D74AD', -1, '2023-09-25 13:52:13.3145658', 'Druff1848                                                                                           ', 2);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x5DA41215EEAA0E2A1B3C57F8E088C491', -1, '2023-09-26 05:49:02.6608336', 'WochenendGLück                                                                                      ', 9);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x87F98FECDB432A8CF4300A0778BBB350', -1, '2023-09-25 13:52:13.7903589', 'GlückAuf                                                                                            ', 7);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\x97FBAB3648559A0E89AC28BFD8C5BFA5', -1, '2023-09-25 13:52:13.3145658', 'VolleRose                                                                                           ', 5);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\xC7E07D31149CB8C2EEDB7C16877DACC7', -1, '2023-09-26 05:49:02.6608336', 'Abendröte                                                                                           ', 8);
INSERT INTO public.hub_vereinspartner (vereinspartner_sk, audit_trail_id, inscription_timestamp, vereinspartner_id, data_delivery_key) VALUES (E'\\xDAD7E35BC3D4E95F4B35274B4167FBAE', -1, '2023-09-25 13:52:13.3145658', 'Blaetterglueck                                                                                      ', 1);
